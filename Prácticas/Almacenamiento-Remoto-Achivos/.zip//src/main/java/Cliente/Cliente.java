package Cliente;

import Servidor.CarpetaObjeto;
import static Servidor.Servidor.zipFile;
import java.net.Socket;
import java.io.*;
import java.util.Scanner;
import java.util.zip.*;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipFile;
import javax.swing.JFileChooser;

public class Cliente {
    public static void main(String[] args) {
        try {
            int pto = 8000;
            String dir = "127.0.0.1";
            Socket cl = new Socket(dir, pto);
            System.out.println("Conexión con servidor establecida...");
            
            DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
            DataInputStream dis = new DataInputStream(cl.getInputStream());
            ObjectOutputStream oos = new ObjectOutputStream(cl.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(cl.getInputStream());
            
            Scanner scanner = new Scanner(System.in);

            String rutaCarpetaLocal = "./CarpetaLocal";

            int opcion = 0;
            while (opcion != 10) {
                System.out.println("1. Listar el contenido de las carpetas local");
                System.out.println("2. Listar el contenido de las carpetas remota");
                System.out.println("3. Crear carpetas local");
                System.out.println("4. Crear carpetas remotamente");
                System.out.println("5. Eliminar carpetas/archivos local");
                System.out.println("6. Eliminar carpetas/archivos remotamente");
                System.out.println("7. Cambiar la ruta de directorio local");
                System.out.println("8. Cambiar la ruta de directorio remotamente");
                System.out.println("9. Enviar archivos desde la carpeta local hacia la remota");
                System.out.println("10. Enviar carpetas desde la carpeta local hacia la remota");
                System.out.println("11. Descargar archivo/carpetas en la carpeta local");
                System.out.println("12. Salir");
                System.out.print("Seleccione una opción: ");

                opcion = scanner.nextInt();

                switch (opcion) {
                    case 1:
                        // Listar contenido de carpeta local
                        System.out.println("Contenido de la carpeta local:");
                        File localFolder = new File(rutaCarpetaLocal);
                        String[] localContents = localFolder.list();
                        for (String item : localContents) {
                            System.out.println(item);
                        }
                        break;
                    case 2:
                        dos.writeInt(1);
                        dos.flush();
                        
                        System.out.println("Contenido de la carpeta remota:");
                        
                        CarpetaObjeto carpetaRecibida = (CarpetaObjeto) ois.readObject();
                        String[] lista = carpetaRecibida.getLista();
                        for (String item : lista) {
                            System.out.println(item);
                        }
                        break;
                    case 3:
                        // Crear carpeta local
                        System.out.println("Ingrese el nombre de la carpeta a crear:");
                        String nuevaCarpeta = scanner.next();
                        File newFolder = new File(rutaCarpetaLocal + "/" + nuevaCarpeta);
                        if (newFolder.mkdir()) {
                            System.out.println("Carpeta creada exitosamente.");
                        } else {
                            System.out.println("Error al crear la carpeta.");
                        }
                        break;
                    case 4:
                        dos.writeInt(2); // Enviar opción al servidor
                        dos.flush();
                        System.out.println("Ingrese el nombre de la carpeta a crear:");
                        String nuevaCarpetaRemota = scanner.next();
                        dos.writeUTF(nuevaCarpetaRemota); // Enviar nombre de la carpeta al servidor
                        dos.flush();
                        String mensajeCreacion = dis.readUTF(); // Recibir mensaje de confirmación del servidor
                        System.out.println(mensajeCreacion);
                        break;
                    case 5:
                        // Eliminar carpeta/archivo local
                        System.out.println("Ingrese el nombre de la carpeta/archivo a eliminar:");
                        String carpetaArchivoEliminar = scanner.next();
                        File itemEliminar = new File(rutaCarpetaLocal + "/" + carpetaArchivoEliminar);
                        if (itemEliminar.exists()) {
                            if (itemEliminar.isDirectory()) {
                                if (itemEliminar.delete()) {
                                    System.out.println("Carpeta eliminada exitosamente.");
                                } else {
                                    System.out.println("Error al eliminar la carpeta.");
                                }
                            } else {
                                if (itemEliminar.delete()) {
                                    System.out.println("Archivo eliminado exitosamente.");
                                } else {
                                    System.out.println("Error al eliminar el archivo.");
                                }
                            }
                        } else {
                            System.out.println("El archivo/carpeta no existe.");
                        }
                        break;
                    case 6:
                        dos.writeInt(3); // Enviar opción al servidor
                        dos.flush();
                        System.out.println("Ingrese el nombre de la carpeta/archivo a eliminar:");
                        String carpetaArchivoEliminarRemoto = scanner.next();
                        dos.writeUTF(carpetaArchivoEliminarRemoto); // Enviar nombre de la carpeta/archivo al servidor
                        dos.flush();
                        String mensajeEliminacion = dis.readUTF(); // Recibir mensaje de confirmación del servidor
                        System.out.println(mensajeEliminacion);
                        break;
                    case 7:
                        // Cambiar la ruta de directorio local
                        System.out.println("Ingrese la nueva ruta del directorio:");
                        String nuevaRuta = scanner.next();
                        rutaCarpetaLocal = nuevaRuta;
                        File newDirectory = new File(rutaCarpetaLocal);
                        if (newDirectory.exists() && newDirectory.isDirectory()) {
                            System.setProperty("user.dir", nuevaRuta);
                            System.out.println("Ruta cambiada exitosamente.");
                        } else {
                            System.out.println("Error al cambiar la ruta. Verifique la existencia del directorio.");
                        }
                        break;
                    case 8:
                        dos.writeInt(4);
                        dos.flush();
                        System.out.println("Ingrese la nueva ruta del directorio:");
                        String nuevaRutaRemota = scanner.next();
                        dos.writeUTF(nuevaRutaRemota);
                        dos.flush();
                        String mensajeCambioRuta = dis.readUTF();
                        System.out.println(mensajeCambioRuta);
                        break;
                    case 9:
                        dos.writeInt(5);
                        dos.flush();
                        System.out.println("Ingrese la ruta del archivo a enviar:");
                        String rutaArchivo = scanner.next();
                        File archivoEnviar = new File(rutaArchivo);
                        if (archivoEnviar.exists()) {
                            String nombre = archivoEnviar.getName();
                            long tam = archivoEnviar.length();
                            System.out.println("Preparándose para enviar archivo " + nombre + " de " + tam + " bytes\n\n");
                            dos.writeUTF(nombre);
                            dos.flush();
                            dos.writeLong(tam);
                            dos.flush();
                            try (FileInputStream fis = new FileInputStream(archivoEnviar)) {
                                byte[] buffer = new byte[3500];
                                int leidos;
                                while ((leidos = fis.read(buffer)) != -1) {
                                    dos.write(buffer, 0, leidos);
                                    dos.flush();
                                }
                                System.out.println("\nArchivo enviado.");
                            } catch (IOException e) {
                                System.err.println("Error al enviar el archivo: " + e.getMessage());
                            }
                        } else {
                            System.out.println("El archivo no existe.");
                        }
                        break;
                    case 10:
                        dos.writeInt(11);
                        dos.flush();
                        System.out.println("Ingrese la ruta de la carpeta a enviar:");
                        String rutaCarpeta = scanner.next();
                        File carpetaEnviar = new File(rutaCarpeta);
                        if (carpetaEnviar.exists() && carpetaEnviar.isDirectory()) {
                            String nombreCarpeta = carpetaEnviar.getName();
                            dos.writeUTF(nombreCarpeta);
                            dos.flush();
                            try {
                                // Comprimir la carpeta antes de enviarla
                                File carpetaComprimida = new File(nombreCarpeta + ".zip");
                                FileOutputStream fos = new FileOutputStream(carpetaComprimida);
                                ZipOutputStream zipOut = new ZipOutputStream(fos);
                                zipFile(carpetaEnviar, carpetaEnviar.getName(), zipOut);
                                zipOut.close();
                                fos.close();

                                // Envía la carpeta comprimida al servidor
                                long tam = carpetaComprimida.length();
                                dos.writeLong(tam);
                                dos.flush();
                                try {
                                    byte[] buffer = new byte[3500];
                                    int leidos;
                                    while ((leidos = dis.read(buffer)) != -1) {
                                        dos.write(buffer, 0, leidos);
                                        dos.flush();
                                    }
                                    System.out.println("\nCarpeta enviada.");
                                } catch (IOException e) {
                                    System.err.println("Error al enviar la carpeta: " + e.getMessage());
                                }
                            } catch (IOException e) {
                                System.err.println("Error al comprimir la carpeta: " + e.getMessage());
                            }
                        } else {
                            System.out.println("La carpeta no existe o no es válida.");
                        }
                        break;
                    case 11:
                        dos.writeInt(7);
                        dos.flush();
                        System.out.println("Ingrese el nombre del archivo a descargar:");
                        String archivoDescargar = scanner.next();
                        dos.writeUTF(archivoDescargar);
                        dos.flush();
                        String mensajeDescargaArchivo = dis.readUTF();
                        System.out.println(mensajeDescargaArchivo);
                        break;
                    case 12:
                        System.out.println("Cerrando la conexión con el servidor...");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        break;
                }
            }
            dos.close();
            oos.close();
            dis.close();
            ois.close();
            cl.close();     
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
